#' Sinuosity data
#'
#' A data frame containingthe sinuosity index from 90 trajectories
#'
#'
#' @format A data frame containingt he sinuosity index from 388 trips of 36 gulls
#' \describe{
#'   \item{Sinuosity}{Sinuosity index}
#'   \item{id}{Subject identifier}
#'   \item{Section}{Time section where the trip started: Day or Night}
#' }
"sin_data"

