icc_est_dep<-function(model_dif){
  
  if(class(model_dif)[1]!='try-error'){
    r.est=icc_est(model_dif)
    
    if( (class(model_dif$apVar)[1]!="character") & (sum(is.na(model_dif$apVar))==0) )
    {
      cov_mat_icc=se_est(model_dif)
      
    }
    else cov_mat_icc<-NA 
    
  } else {r.est<-NA;cov_mat_icc<-NA}
  
  return(list(ICC=r.est$r.est,S=cov_mat_icc,Gmat=r.est$Gmat,
              Smat=r.est$Smat))
} 
