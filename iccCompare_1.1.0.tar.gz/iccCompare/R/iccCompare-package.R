
#' @name iccCompare
#' 
#' @description
#' iccCompare: Tools for Comparing Dependent Intraclass Correlation Coefficients.
#'
#' Provides functions to test the equality of dependent ICCs using various methods.
#' 
#' @details
#' See the package DESCRIPTION file for more information.
#' @keywords internal
"_PACKAGE"

