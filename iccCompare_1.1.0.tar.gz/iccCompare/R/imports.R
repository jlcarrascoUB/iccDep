
#' @importFrom utils combn globalVariables
#' @importFrom stats quantile sd qnorm pchisq pnorm rnorm rpois
#' @importFrom nlme lme varIdent getVarCov
#' @importFrom dplyr group_by summarise mutate rename select ungroup summarize arrange any_of all_of %>% n
#' @importFrom Deriv Deriv
#' @importFrom MASS ginv mvrnorm
#' @importFrom furrr future_map furrr_options
#' @importFrom future plan
#' @importFrom progressr progressor with_progress
#' @importFrom parallelly availableCores
#' @importFrom bbmle mle2
#' @importFrom mvtnorm dmvnorm
utils::globalVariables(c("y","ind","type","k", "k2", "sk", "sk2", "N", "n",
                         "data_sim","i"))
NULL
