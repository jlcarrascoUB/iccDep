se_est<-function(model_dif){
  
  nt<-length(unique(model_dif$data$type))
  
  vars<-attr(model_dif$apVar,"Pars")
  
  P<-model_dif$apVar
  
  # Derivades
  
  # First icc
  
  dev<-rep(0,nrow(P))
  dev[1]<-e1(vars[1],0,vars[nrow(P)])
  dev[nrow(P)]<-e3(vars[1],0,vars[nrow(P)])
  
  
  # Remaining ICC
  
  for (i in (2:nt)){
    aux<-rep(0,nrow(P))
    aux[i]<-e1(vars[i],vars[nrow(P)-(nt-i+1)],vars[nrow(P)])
    aux[nrow(P)-(nt-i+1)]<-e2(vars[i],vars[nrow(P)-(nt-i+1)],vars[nrow(P)])
    aux[nrow(P)]<-e3(vars[i],vars[nrow(P)-(nt-i+1)],vars[nrow(P)])
    
    dev<-cbind(dev,aux)  
    
  }
  
  S<-t(dev)%*%P%*%dev
  
  row.names(S)<-levels(model_dif$data$type)
  colnames(S)<-levels(model_dif$data$type)
  
  return(S)
  
}